# UrnTheory.R
# This opens the file UrnTheory.pdf to explain the biased urn models.

vignette("UrnTheory", package="BiasedUrn")
